/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.witc.PetHotel.data;

import edu.witc.PetHotel.business.PetType;
import static edu.witc.PetHotel.util.DateUtil.getSqlDate;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author mlens_000
 */
public class PetTypeDb {
    public static List<PetType> getAllPetTypes(){
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<PetType> petTypes = new ArrayList<>();
        
        String sql = "SELECT id, short_desc, long_desc, active "
                + "FROM pet_type";
        try{
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                PetType petType = new PetType();
                petType.setPetTypeId(rs.getInt("id"));
                petType.setShortDesc(rs.getString("short_desc"));
                petType.setLongDesc(rs.getString("long_desc"));
                petType.setActive(rs.getBoolean("active"));
                petTypes.add(petType);                   
            }
        }
        catch(SQLException e){
            System.out.println("getAllPetTypes: " + e);
            return null;
        }
        finally{
            DbHelper.closeResultSet(rs);
            DbHelper.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
        return petTypes;
    }
    
    public static List<PetType> getAllActivePetTypes(){
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<PetType> petTypes = new ArrayList<>();
        
        String sql = "SELECT id, short_desc, long_desc, active "
                + "FROM pet_type WHERE active = 1";
        try{
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                PetType petType = new PetType();
                petType.setPetTypeId(rs.getInt("id"));
                petType.setShortDesc(rs.getString("short_desc"));
                petType.setLongDesc(rs.getString("long_desc"));
                petType.setActive(rs.getBoolean("active"));
                petTypes.add(petType);                   
            }
        }
        catch(SQLException e){
            System.out.println("getAllPetTypes: " + e);
            return null;
        }
        finally{
            DbHelper.closeResultSet(rs);
            DbHelper.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
        return petTypes;
    }
    
     public static int insert(PetType petType) throws SQLException
    {
        String sql = "INSERT INTO pet_type(short_desc, long_desc, date_added, date_modified) VALUES (?,?,?,?)";
        
        int rowsEffected = 0;
        
        Connection connection = DbConnectionUtil.getConnection();
            
            try (PreparedStatement ps = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS))
            {
                //ps.setInt(1, customer.getCustomerId());
                ps.setString(1, petType.getShortDesc());
                ps.setString(2, petType.getLongDesc());
                ps.setDate(3, getSqlDate());
                ps.setDate(4, getSqlDate());
                rowsEffected = ps.executeUpdate();
                
                if(rowsEffected > 0)
                {
                    ResultSet rs = ps.getGeneratedKeys();
                    if(rs.next())
                    {
                        rowsEffected = rs.getInt(1);
                    }//end of nested if
                }//end of nested if
            }//end of try
            catch (SQLException e)
            {
                throw new SQLException(e);
            }
            return rowsEffected;
    }//end of insert()
    
    public static PetType getById(String Id) throws SQLException
    {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        String query = "SELECT * FROM pet_type WHERE id = ?";

        try
        {
            ps = connection.prepareStatement(query);
            ps.setString(1, Id);
            rs = ps.executeQuery();
            PetType petType = null;
            if (rs.next()) 
            {
                petType = new PetType();
                petType.setPetTypeId(Integer.parseInt(rs.getString("id")));
                petType.setShortDesc(rs.getString("short_desc"));
                petType.setLongDesc(rs.getString("long_desc"));
                petType.setActive(rs.getBoolean("active"));
            }
            return petType;
        }
        catch (SQLException ex)
        {
            return null;
        }
        finally
        {
            DbConnectionUtil.closeResultSet(rs);
            DbConnectionUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }
    
    
    public static int updateValid(PetType petType) throws SQLException
    {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        
        String sql = "UPDATE pet_type SET "
                + "active = ? WHERE id = ?";
        
        //int rowsEffected = 0;
        
        //Connection connection = DbConnectionUtil.getConnection();
            try
            {
                ps = connection.prepareStatement(sql);
                ps.setBoolean(1, petType.isActive());
                ps.setInt(2, petType.getPetTypeId());
                return ps.executeUpdate();
            }//end of try
            catch(SQLException ex)
            {
                throw new SQLException(ex);
            }//end of catch
            finally
            {
                DbConnectionUtil.closePreparedStatement(ps);
                pool.freeConnection(connection);
            }
//return rowsEffected;
    }//end of update()
    
    public static boolean petTypeExists(String longDesc)
    {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        String query = "SELECT long_desc FROM pet_type WHERE long_desc = ?";
        
        try
        {
            ps = connection.prepareStatement(query);
            ps.setString(1, longDesc);
            rs = ps.executeQuery();
            return rs.next();
            
        }
        catch(SQLException ex)
        {
            return false;
        }
        finally
        {
            DbConnectionUtil.closeResultSet(rs);
            DbConnectionUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }//end of method dispositionExists
}

    
    

