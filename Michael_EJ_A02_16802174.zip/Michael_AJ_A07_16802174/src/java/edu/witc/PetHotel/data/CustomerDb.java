/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.witc.PetHotel.data;

import edu.witc.PetHotel.business.Customer;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 *
 * @author mlens_000
 */
public class CustomerDb {
    private static java.sql.Date getSqlDate()
    {
        java.time.LocalDate today = java.time.LocalDate.now();
        java.sql.Date sqlDate = java.sql.Date.valueOf(today);
        
        return sqlDate;
    }//end of setSqlDate();
    
    public static List<Customer> getByName(String lastName) throws SQLException
    {        
        String query = "SELECT * FROM customer WHERE last_name = ?";

        
        
        List<Customer> customers = new ArrayList<>();
        //Customer customer;
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        //Connection connection = DbConnectionUtil.getConnection();
        
        try /*( PreparedStatement ps = connection.prepareStatement(sql);
                ResultSet rs = ps.executeQuery() )*/
        {
            ps = connection.prepareStatement(query);
            ps.setString(1, lastName);
            rs = ps.executeQuery();
            while(rs.next()){
                Customer customer = new Customer();
                customer.setCustomerId(rs.getInt("id"));
                customer.setFirstName(rs.getString("first_name"));
                customer.setLastName(rs.getString("last_name"));
                customer.setPhone(rs.getString("phone"));
                customer.setEmail(rs.getString("email"));
                customer.setAddress(rs.getString("street_address"));
                customer.setCity(rs.getString("city"));
                customer.setState(rs.getInt("state_id"));
                customer.setPostalCode(rs.getString("postal_code"));            
                customer.setIsActive(rs.getBoolean("active"));
                customers.add(customer);
            }
            
            return customers;
        }//end of try
        catch(SQLException e)
        {
            throw new SQLException(e);
        }//end of catch*/
        finally
        {
            DbConnectionUtil.closeResultSet(rs);
            DbConnectionUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }

    }//end of getByName()
    
    public static List<Customer> getAll() throws SQLException
    {
        String sql = "SELECT * FROM customer";
        
        List<Customer> customers = new ArrayList<>();
        //Customer customer;
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        //Connection connection = DbConnectionUtil.getConnection();
        
        try /*( PreparedStatement ps = connection.prepareStatement(sql);
                ResultSet rs = ps.executeQuery() )*/
        {
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                Customer customer = new Customer();
                customer.setCustomerId(rs.getInt("id"));
                customer.setFirstName(rs.getString("first_name"));
                customer.setLastName(rs.getString("last_name"));
                customer.setPhone(rs.getString("phone"));
                customer.setEmail(rs.getString("email"));
                customer.setAddress(rs.getString("street_address"));
                customer.setCity(rs.getString("city"));
                customer.setState(rs.getInt("state_id"));
                customer.setPostalCode(rs.getString("postal_code"));            
                customer.setIsActive(rs.getBoolean("active"));
                customers.add(customer);
            }
            
            return customers;
        }//end of try
        catch(SQLException e)
        {
            throw new SQLException(e);
        }//end of catch*/
        finally
        {
            DbConnectionUtil.closeResultSet(rs);
            DbConnectionUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }//end of getAll()
    
    public static Customer getById(String Id) throws SQLException
    {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        String query = "SELECT * FROM customer WHERE id = ?";

        try
        {
            ps = connection.prepareStatement(query);
            ps.setString(1, Id);
            rs = ps.executeQuery();
            Customer customer = null;
            if (rs.next()) 
            {
                customer = new Customer();
                customer.setCustomerId(Integer.parseInt(rs.getString("id")));
                customer.setFirstName(rs.getString("first_name"));
                customer.setLastName(rs.getString("last_name"));
                customer.setPhone(rs.getString("phone"));
                customer.setAddress(rs.getString("street_address"));
                customer.setEmail(rs.getString("email"));
                customer.setCity(rs.getString("city"));
                customer.setState(Integer.parseInt(rs.getString("state_id")));
                customer.setPostalCode(rs.getString("postal_code"));
                customer.setComments(rs.getString("comments"));
            }
            return customer;
        }
        catch (SQLException ex)
        {
            return null;
        }
        finally
        {
            DbConnectionUtil.closeResultSet(rs);
            DbConnectionUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }
    
    public static Customer getByPhone(String phone) throws SQLException
    {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        String query = "SELECT * FROM customer WHERE phone = ?";

        try
        {
            ps = connection.prepareStatement(query);
            ps.setString(1, phone);
            rs = ps.executeQuery();
            Customer customer = null;
            if (rs.next()) 
            {
                customer = new Customer();
                customer.setCustomerId(Integer.parseInt(rs.getString("id")));
                customer.setFirstName(rs.getString("first_name"));
                customer.setLastName(rs.getString("last_name"));
                customer.setPhone(rs.getString("phone"));
                customer.setAddress(rs.getString("street_address"));
                customer.setEmail(rs.getString("email"));
                customer.setCity(rs.getString("city"));
                customer.setState(Integer.parseInt(rs.getString("state_id")));
                customer.setPostalCode(rs.getString("postal_code"));
                customer.setComments(rs.getString("comments"));
            }
            return customer;
        }
        catch (SQLException ex)
        {
            return null;
        }
        finally
        {
            DbConnectionUtil.closeResultSet(rs);
            DbConnectionUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
        
    }//end of getByPhone()
    
    public static int insert(Customer customer) throws SQLException
    {
        String sql = "INSERT INTO customer(first_name, last_name, phone, email, street_address, city, state_id, postal_code, comments, active, date_added, date_modified) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";
        
        int rowsEffected = 0;
        
        Connection connection = DbConnectionUtil.getConnection();
            
            try (PreparedStatement ps = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS))
            {
                //ps.setInt(1, customer.getCustomerId());
                ps.setString(1, customer.getFirstName());
                ps.setString(2, customer.getLastName());
                ps.setString(3, customer.getPhone());
                ps.setString(4, customer.getEmail());
                ps.setString(5, customer.getAddress());
                ps.setString(6, customer.getCity());
                ps.setInt(7, customer.getStateId());
                ps.setString(8, customer.getPostalCode());
                ps.setString(9, customer.getComments());
                ps.setBoolean(10, customer.isActive());
                ps.setDate(11, getSqlDate());
                ps.setDate(12, getSqlDate());
                rowsEffected = ps.executeUpdate();
                
                if(rowsEffected > 0)
                {
                    ResultSet rs = ps.getGeneratedKeys();
                    if(rs.next())
                    {
                        rowsEffected = rs.getInt(1);
                    }//end of nested if
                }//end of nested if
            }//end of try
            catch (SQLException e)
            {
                throw new SQLException(e);
            }
            return rowsEffected;
    }//end of insert()
    
    public static int update(Customer customer) throws SQLException
    {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        
        String sql = "UPDATE customer SET "
                + "first_name = ?, last_name = ?,"
                + "phone = ?, email = ?,"
                + "street_address = ?, city = ?,"
                + " state_id = ?, postal_code = ?,"
                + "comments = ?, active = ?,"
                + "date_modified = ? WHERE id = ?";
        
        //int rowsEffected = 0;
        
        //Connection connection = DbConnectionUtil.getConnection();
            try
            {
                ps = connection.prepareStatement(sql);
                ps.setString(1, customer.getFirstName());
                ps.setString(2, customer.getLastName());
                ps.setString(3, customer.getPhone());
                ps.setString(4, customer.getEmail());
                ps.setString(5, customer.getAddress());
                ps.setString(6, customer.getCity());
                ps.setInt(7, customer.getStateId());
                ps.setString(8, customer.getPostalCode());
                ps.setString(9, customer.getComments());
                ps.setBoolean(10, customer.isActive());
                ps.setDate(11, getSqlDate());
                ps.setInt(12, customer.getCustomerId());
                return ps.executeUpdate();
            }//end of try
            catch(SQLException ex)
            {
                throw new SQLException(ex);
            }//end of catch
            finally
            {
                DbConnectionUtil.closePreparedStatement(ps);
                pool.freeConnection(connection);
            }
//return rowsEffected;
    }//end of update()
    
    public static boolean phoneExists(String phone)
    {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        String query = "SELECT phone FROM customer WHERE phone = ?";
        
        try
        {
            ps = connection.prepareStatement(query);
            ps.setString(1, phone);
            rs = ps.executeQuery();
            return rs.next();
        }
        catch(SQLException ex)
        {
            return false;
        }
        finally
        {
            DbConnectionUtil.closeResultSet(rs);
            DbConnectionUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }//end of phoneExists
    
    public static boolean nameExists(String lastName)
    {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        String query = "SELECT last_name FROM customer WHERE last_name = ?";
        
        try
        {
            ps = connection.prepareStatement(query);
            ps.setString(1, lastName);
            rs = ps.executeQuery();
            return rs.next();
            
        }
        catch(SQLException ex)
        {
            return false;
        }
        finally
        {
            DbConnectionUtil.closeResultSet(rs);
            DbConnectionUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }//end of method nameExists
    
}
