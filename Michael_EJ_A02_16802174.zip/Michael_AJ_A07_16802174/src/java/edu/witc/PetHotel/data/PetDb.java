/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.witc.PetHotel.data;

import edu.witc.PetHotel.business.Pet;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author mlens_000
 */
public class PetDb {
    private static java.sql.Date getSqlDate()
    {
        java.time.LocalDate today = java.time.LocalDate.now();
        java.sql.Date sqlDate = java.sql.Date.valueOf(today);
        
        return sqlDate;
    }//end of setSqlDate();
    
    public static List<Pet> getAll() throws SQLException
    {
        String query = "SELECT * FROM Pet";
       
        
        List<Pet> pets = new ArrayList<>();
        
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
 
        try
        {
            ps = connection.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) 
            {
                Pet pet = new Pet();
                pet.setCustomerId(Integer.parseInt(rs.getString("customer_id")));
                pet.setName(rs.getString("pet_name"));
                pet.setGender(rs.getString("gender"));
                pet.setPetTypeId(rs.getInt("pet_type_id"));
                pet.setBirthDate(rs.getString("month_year_born"));
                pet.setDispositionTypeId(rs.getInt("disposition_type_id"));
                pet.setCoughDate(rs.getDate("date_last_kennel_cough"));
                pet.setComments(rs.getString("comments"));
                pet.setIsActive(rs.getBoolean("active"));
                pets.add(pet);
            }
            return pets;
        }
        catch (SQLException ex)
        {
            return null;
        }
        finally
        {
            DbConnectionUtil.closeResultSet(rs);
            DbConnectionUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }//end of getAll()
    
    public static int insert(Pet pet) throws SQLException
    {
        String sql = "INSERT INTO pet(customer_id, pet_name, gender, pet_type_id, month_year_born, disposition_type_id, date_last_kennel_cough, breed, comments, active, date_added, date_modified) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";
        
        int rowsEffected = 0;
        
        Connection connection = DbConnectionUtil.getConnection();
            
            try (PreparedStatement ps = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS))
            {
                ps.setInt(1, pet.getCustomerId());
                ps.setString(2, pet.getName());
                ps.setString(3, pet.getGender());
                ps.setInt(4, pet.getPetTypeId());
                ps.setString(5, pet.getBirthDate());
                ps.setInt(6, pet.getDispositionTypeId());
                ps.setDate(7, pet.getCoughDate());
                ps.setString(8, pet.getBreed());
                ps.setString(9, pet.getComments());
                ps.setBoolean(10, pet.isActive());
                ps.setDate(11, getSqlDate());
                ps.setDate(12, getSqlDate());
                rowsEffected = ps.executeUpdate();
                
                if(rowsEffected > 0)
                {
                    ResultSet rs = ps.getGeneratedKeys();
                    if(rs.next())
                    {
                        rowsEffected = rs.getInt(1);
                    }//end of nested if
                }//end of nested if
            }//end of try
            catch (SQLException e)
            {
                throw new SQLException(e);
            }
            return rowsEffected;
    }//end of insert()
    
    public static int update(Pet pet) throws SQLException
    {
        String sql = "UPDATE customer SET "
                + "pet_name = ?, gender = ?,"
                + "pet_type_id = ?, month_year_born = ?,"
                + "disposition_type_id = ?, date_last_kennel_cough = ?,"
                + " breed = ?, comments = ?,"
                + "active = ?, date_added = ?,"
                + "date_modified = ?, WHERE id = ?";
        
        int rowsEffected = 0;
        
        Connection connection = DbConnectionUtil.getConnection();
            try(PreparedStatement ps = connection.prepareStatement(sql))
            {
                ps.setInt(1, pet.getCustomerId());
                ps.setString(2, pet.getName());
                ps.setString(3, pet.getGender());
                ps.setInt(4, pet.getPetTypeId());
                ps.setString(5, pet.getBirthDate());
                ps.setInt(6, pet.getDispositionTypeId());
                ps.setDate(7, pet.getCoughDate());
                ps.setString(8, pet.getBreed());
                ps.setString(9, pet.getComments());
                ps.setBoolean(10, pet.isActive());
                ps.setDate(11, getSqlDate());
                ps.setDate(12, getSqlDate());
                rowsEffected = ps.executeUpdate();
            }//end of try
            catch(SQLException e)
            {
                throw new SQLException(e);
            }//end of catch
            return rowsEffected;
    }//end of update()
    
    
    public static List<Pet> getById(int customerId) throws SQLException
    {
                
        String query = "SELECT * FROM Pet WHERE customer_id = ?";
       
        
        List<Pet> pets = new ArrayList<>();
        
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
 
        try
        {
            ps = connection.prepareStatement(query);
            ps.setInt(1, customerId);
            rs = ps.executeQuery();
            while (rs.next()) 
            {
                Pet pet = new Pet();
                pet.setCustomerId(Integer.parseInt(rs.getString("customer_id")));
                pet.setName(rs.getString("pet_name"));
                pet.setGender(rs.getString("gender"));
                pet.setPetTypeId(rs.getInt("pet_type_id"));
                pet.setBirthDate(rs.getString("month_year_born"));
                pet.setDispositionTypeId(rs.getInt("disposition_type_id"));
                pet.setCoughDate(rs.getDate("date_last_kennel_cough"));
                pet.setComments(rs.getString("comments"));
                pet.setIsActive(rs.getBoolean("active"));
                pets.add(pet);
            }
            return pets;
        }
        catch (SQLException ex)
        {
            return null;
        }
        finally
        {
            DbConnectionUtil.closeResultSet(rs);
            DbConnectionUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }
    
    
    public static boolean customerIdExists(int customerId)
    {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        String query = "SELECT customer_id FROM pet WHERE customer_id = ?";
        
        try
        {
            ps = connection.prepareStatement(query);
            ps.setInt(1, customerId);
            rs = ps.executeQuery();
            return rs.next();
        }
        catch(SQLException ex)
        {
            return false;
        }
        finally
        {
            DbConnectionUtil.closeResultSet(rs);
            DbConnectionUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }
    
}
