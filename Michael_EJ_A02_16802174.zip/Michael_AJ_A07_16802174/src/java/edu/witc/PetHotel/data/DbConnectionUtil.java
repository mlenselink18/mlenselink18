/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.witc.PetHotel.data;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author mlens_000
 */
public class DbConnectionUtil 
{
    
    private static Connection connection;
    private static final String DATABASE_URL = "jdbc:mysql://localhost:3308/pet_hotel_basic";
    private static final String USER_NAME = "root";
    private static final String PASSWORD = "sesame";
    
    protected static synchronized Connection getConnection() throws SQLException
    {
        if(connection != null)
        {
            return connection;
        }//end of if
        else
        {
            try
            {
                connection = DriverManager.getConnection(DATABASE_URL, USER_NAME, PASSWORD);
                                System.out.println("connected");
            }//end of try
            catch(SQLException e)
            {
                                System.out.println("not connected");
                throw new SQLException(e);
            }//end of catch
            return connection;
        }//end of else
    }//end of getConnection
    
    public static void closePreparedStatement(Statement ps)
    {
        try
        {
            if(ps != null)
            {
                ps.close();
            }
        }
        catch (SQLException ex)
        {

        }
    }//end of closePreparedStatement
    
    public static void closeResultSet(ResultSet rs)
    {
        try
        {
            if (rs != null)
            {
                rs.close();
            }
        }
        catch(SQLException ex)
        {
            
        }
    }// end of method closeResultSet
}//end of class