/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.witc.PetHotel.data;

import edu.witc.PetHotel.business.DispositionType;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author mlens_000
 */
public class DispositionTypeDb {
    
    public static List<DispositionType> getAllDispoTypes(){
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<DispositionType> dispoTypes = new ArrayList<>();
        
        String sql = "SELECT id, short_desc, long_desc, active "
                + "FROM disposition_type";
        try{
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                DispositionType dispoType = new DispositionType();
                dispoType.setDispoId(rs.getInt("id"));
                dispoType.setShortDesc(rs.getString("short_desc"));
                dispoType.setLongDesc(rs.getString("long_desc"));
                dispoType.setActive(rs.getBoolean("active"));
                dispoTypes.add(dispoType);                   
            }
        }
        catch(SQLException e){
            System.out.println("getAllDispoTypes: " + e);
            return null;
        }
        finally{
            DbHelper.closeResultSet(rs);
            DbHelper.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
        return dispoTypes;
        
    }
    
    
    public static DispositionType getById(String Id) throws SQLException
    {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        String query = "SELECT * FROM disposition_type WHERE id = ?";

        try
        {
            ps = connection.prepareStatement(query);
            ps.setString(1, Id);
            rs = ps.executeQuery();
            DispositionType dispoType = null;
            if (rs.next()) 
            {
                dispoType = new DispositionType();
                dispoType.setDispoId(Integer.parseInt(rs.getString("id")));
                dispoType.setShortDesc(rs.getString("short_desc"));
                dispoType.setLongDesc(rs.getString("long_desc"));
                dispoType.setActive(rs.getBoolean("active"));
            }
            return dispoType;
        }
        catch (SQLException ex)
        {
            return null;
        }
        finally
        {
            DbConnectionUtil.closeResultSet(rs);
            DbConnectionUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }
    
    
    public static int updateValid(DispositionType dispoType) throws SQLException
    {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        
        String sql = "UPDATE disposition_type SET "
                + "active = ? WHERE id = ?";
        
        //int rowsEffected = 0;
        
        //Connection connection = DbConnectionUtil.getConnection();
            try
            {
                ps = connection.prepareStatement(sql);
                ps.setBoolean(1, dispoType.isActive());
                ps.setInt(2, dispoType.getDispoId());
                return ps.executeUpdate();
            }//end of try
            catch(SQLException ex)
            {
                throw new SQLException(ex);
            }//end of catch
            finally
            {
                DbConnectionUtil.closePreparedStatement(ps);
                pool.freeConnection(connection);
            }
//return rowsEffected;
    }//end of update()
    
    public static boolean dispositionExists(String longDesc)
    {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        String query = "SELECT long_desc FROM disposition_type WHERE long_desc = ?";
        
        try
        {
            ps = connection.prepareStatement(query);
            ps.setString(1, longDesc);
            rs = ps.executeQuery();
            return rs.next();
            
        }
        catch(SQLException ex)
        {
            return false;
        }
        finally
        {
            DbConnectionUtil.closeResultSet(rs);
            DbConnectionUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }//end of method dispositionExists
}
