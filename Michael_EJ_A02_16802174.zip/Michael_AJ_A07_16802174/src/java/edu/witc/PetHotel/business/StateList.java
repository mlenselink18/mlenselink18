/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.witc.PetHotel.business;

import java.io.Serializable;

/**
 *
 * @author mlens_000
 */
public class StateList implements Serializable{
    private int stateId;
    private String shortDesc;
    private String longDesc;
    private boolean active;
    
    public StateList(){
        
    }//end of constructor
    
    public StateList(int id, String shortDesc, String longDesc, boolean isActive){
        this.stateId = id;
        this.shortDesc = shortDesc;
        this.longDesc = longDesc;
        this.active = isActive;
    }
    
     public void setStateId(int stateId) {
        this.stateId = stateId;
    }

    public void setShortDesc(String shortDesc) {
        this.shortDesc = shortDesc;
    }

    public void setLongDesc(String longDesc) {
        this.longDesc = longDesc;
    }

    public int getStateId() {
        return stateId;
    }

    public String getShortDesc() {
        return shortDesc;
    }

    public String getLongDesc() {
        return longDesc;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }
}
