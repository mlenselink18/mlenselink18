/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.witc.PetHotel.business;

import java.io.Serializable;
import java.sql.Date;

/**
 *
 * @author mlens_000
 */
public class Customer implements Serializable{
    
    private int customerId;
    private String firstName;
    private String lastName;
    private String email;
    private String phone;
    private String address;
    private String city;
    private int stateId;
    private String postalCode;
    private String comments;
    private boolean isActive;
    private Date dateAdded;
    private Date dateModified;
    
    public Customer()
    {
        this(0, "", "", "", "", "", "", 0, "", "", true, null, null);
    }
    
    public Customer(int customerId, String firstName, String lastName, String email, String phone, String address, String city, int stateId, String postalCode, String comments, boolean isActive, Date dateAdded, Date dateModified)
    {
        
    }
    
    public int getCustomerId()
    {
        return customerId;
    }
    
    public void setCustomerId(int customerId)
    {
        this.customerId = customerId;
    }
    
    public String getFirstName()
    {
        return firstName;
    }
    
    public void setFirstName(String firstName)
    {
        this.firstName = firstName;
    }
    
    public String getLastName()
    {
        return lastName;
    }
    
    public void setLastName(String lastName)
    {
        this.lastName = lastName;
    }
    
    public String getEmail()
    {
        return email;
    }
    
    public void setEmail(String email)
    {
        this.email = email;
    }
    
    /*public String getCustomerNumber()
    {
        return customerNumber;
    }
    
    public void setCustomerNumber(String customerNumber)
    {
        this.customerNumber = customerNumber;
    }*/
    
    public String getPhone()
    {
        return phone;
    }
    
    public void setPhone(String phone)
    {
        this.phone = phone;
    }
    
    public String getAddress()
    {
        return address;
    }
    
    public void setAddress(String address)
    {
        this.address = address;
    }
    
    public String getCity()
    {
        return city;
    }
    
    public void setCity(String city)
    {
        this.city = city;
    }
    
    public int getStateId()
    {
        return stateId;
    }
    
    public void setState(int stateId)
    {
        this.stateId = stateId;
    }
    
    public String getPostalCode()
    {
        return postalCode;
    }
    
    public void setPostalCode(String postalCode)
    {
        this.postalCode = postalCode;
    }
    
    public boolean isActive()
    {
        return isActive;
    }
    
    public void setIsActive(boolean isActive)
    {
        this.isActive = isActive;
    }
    
    public String getComments()
    {
        return comments;
    }
    
    public void setComments(String comments)
    {
        this.comments = comments;
    }
}
