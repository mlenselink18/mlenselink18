/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.witc.PetHotel.business;

import java.io.Serializable;
import java.sql.Date;

/**
 *
 * @author mlens_000
 */
public class Pet implements Serializable{
    
    private int petId;
    private int customerId;
    private String name;
    private String gender;
    private int petTypeId;
    private String birthDate;
    private int dispositionTypeId;
    private Date coughDate;
    private String breed;
    private String comments;
    private boolean isActive;
    private Date dateAdded;
    private Date dateModified;
    
    public Pet()
    {
        this(0, "", "", 0, "", 0, null, "", "", true, null, null);
    }
    
    public Pet(int customerId, String name, String gender, int petTypeId, String birthDate, int dispositionTypeId, Date coughDate, String breed, String comments, boolean isActive, Date dateAdded, Date dateModified)
    {
        
    }
    
    public int getCustomerId()
    {
        return customerId;
    }
    
    public void setCustomerId(int customerId)
    {
        this.customerId = customerId;
    }
    
    public String getName()
    {
        return name;
    }
    
    public void setName(String name)
    {
        this.name = name;
    }
    
    public String getGender()
    {
        return gender;
    }
    
    public void setGender(String gender)
    {
        this.gender = gender;
    }
    
    public int getPetTypeId()
    {
        return petTypeId;
    }
    
    public void setPetTypeId(int petTypeId)
    {
        this.petTypeId = petTypeId;
    }
    
    public String getBirthDate()
    {
        return birthDate;
    }
    
    public void setBirthDate(String birthDate)
    {
        this.birthDate = birthDate;
    }
    
    public int getDispositionTypeId()
    {
        return dispositionTypeId;
    }
    
    public void setDispositionTypeId(int dispositionTypeId)
    {
        this.dispositionTypeId = dispositionTypeId;
    }
    
    public Date getCoughDate()
    {
        return coughDate;
    }
    
    public void setCoughDate(Date coughDate)
    {
        this.coughDate = coughDate;
    }
    
    public String getComments()
    {
        return comments;
    }
    
    public void setComments(String comments)
    {
        this.comments = comments;
    }
    
    public String getBreed()
    {
        return breed;
    }
    
    public void setBreed(String breed)
    {
        this.breed = breed;
    }
    
    public boolean isActive()
    {
        return isActive;
    }
    
    public void setIsActive(boolean isActive)
    {
        this.isActive = isActive;
    }
}
