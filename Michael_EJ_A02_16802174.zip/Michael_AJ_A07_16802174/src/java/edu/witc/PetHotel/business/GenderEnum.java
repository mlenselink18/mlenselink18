/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.witc.PetHotel.business;

/**
 *
 * @author mlens_000
 */
public enum GenderEnum {
    
    FEMALE("Female"),
    MALE("Male"),
    UNKNOWN("Unknown");
    
    private final String displayValue;
    
    private GenderEnum(final String value)
    {
        displayValue = value;
    }
    
    @Override
    public String toString()
    {
        return displayValue;
    }
    
}
