/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.witc.PetHotel.Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.witc.PetHotel.util.ValidatorUtil;
import edu.witc.PetHotel.business.Customer;
import edu.witc.PetHotel.business.DispositionType;
import edu.witc.PetHotel.business.GenderEnum;
import edu.witc.PetHotel.business.Pet;
import edu.witc.PetHotel.business.PetType;
import edu.witc.PetHotel.business.StateList;
import edu.witc.PetHotel.data.CustomerDb;
import edu.witc.PetHotel.data.DispositionTypeDb;
import edu.witc.PetHotel.data.PetDb;
import edu.witc.PetHotel.data.PetTypeDb;
import edu.witc.PetHotel.data.StateListDb;
import edu.witc.PetHotel.util.DateUtil;
import edu.witc.PetHotel.util.DateUtil.DateFormats;
import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpSession;
import java.util.Random;
import javax.servlet.ServletContext;

/**
 *
 * @author mlens_000
 */
public class PetHotelServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    
    

    protected void processRequest(HttpServletRequest request, HttpServletResponse response, String url)
            throws ServletException, IOException {
        
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            /*out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet PetHotelNewServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet PetHotelNewServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");*/
            getServletContext().getRequestDispatcher(url)
                .forward(request, response);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);
        String action = request.getParameter("action");
        String url = "";
        setPageData(request);
        
        switch (action) 
            {
            case "customer":
                url = "/customerAdd.jsp";
                break;
            case "manage":
                url = "/customerManage.jsp";
                break;
            case "search":
                url = "/customerSearch.jsp";
                break;
            case "anotherOne":
                resetMessage(request, response);
                url = "/index.jsp";
                break;
            }
        processRequest(request, response, url);
        
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
        
        String action = request.getParameter("action");
        String url = "";
        setPageData(request);
        
        
        
        switch(action)
        {
            case "doCustomer":
                url = doCustomer(request, response);
                break;
            case "doPet":
                url = doPet(request, response);
                break;
            case "doSearch":
                url = doSearch(request, response);
                break;
            case "doManageCustomer":
                url = doManageCustomer(request,response);
                break;
            case "doManagePet":
                url = doManagePet(request,response);
                break;
            case "doAllPets":
                url = doManagePet(request, response);
                break;
            case "index":
                url = doHome(request, response);
                break;
            case "error":
                url = "/error_404.jsp";
                break;
        }
        
        getServletContext().getRequestDispatcher(url)
            .forward(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    private String doHome(HttpServletRequest request, HttpServletResponse response)
    {
        String url = "/index.jsp";
        resetMessage(request, response);
        
        return url;
    }
    
    private String doManageCustomer(HttpServletRequest request, HttpServletResponse response)
    {
        String url = "";
        String message = "";
        String customerId = request.getParameter("customerId");
        Customer customer = new Customer();
        HttpSession session = request.getSession();
        String sessionType = "";
        
        try
        {
        customer = CustomerDb.getById(customerId);
        int stateId = customer.getStateId();
        session.setAttribute("customer", customer);
        url = "/customerAdd.jsp";
        message = "Update customer information for customer number " + customerId;
        sessionType = "manage";
        session.setAttribute("message", message);
        session.setAttribute("stateId", stateId);
        session.setAttribute("customerId", customerId);
        session.setAttribute("sessionType", sessionType);
        }
        catch(SQLException ex)
        {
        message = ex.toString();
        url = "/index.jsp";
        }
        
        return url;
    }
    
    private String doManagePet(HttpServletRequest request, HttpServletResponse response)
    {
        String url = "";

        String action = request.getParameter("action");
        String message = "";
        String customerId = request.getParameter("customerId");
        Customer customer = new Customer();
        HttpSession session = request.getSession();
        String sessionType = "";
        
        
        switch(action)
        {
            case "doManagePet":
                try
                {
                customer = CustomerDb.getById(customerId);
                }
                catch(SQLException e)
                {
                    message = "Error loading customer profile: " + e.toString();
                    url = "/customerManage.jsp";
                }

                if (PetDb.customerIdExists(Integer.parseInt(customerId)) == true)
                {
                    try
                    {
                    List<Pet> petList = PetDb.getById(Integer.parseInt(customerId));
                    request.setAttribute("petList", petList);
                    message = "Viewing pets for customer " + customerId;
                    sessionType = "managePet";
                    url = "/petManage.jsp";
                    }
                    catch(SQLException ex)
                    {
                    message = "Error loading pets: " + ex.toString();
                    url = "/customerManage.jsp";
                    }
                }
                else
                {
                    message = "No pets found for customer " + customerId;
                    url = "/customerManage.jsp";
                }
                break;//end of case "doManagePet"
            case "doAllPets":
                try
                    {
                    List<Pet> petList = PetDb.getAll();
                    request.setAttribute("petList", petList);
                    message = "Viewing all pets";
                    sessionType = "managePet";
                    url = "/petManage.jsp";
                    }
                    catch(SQLException ex)
                    {
                    message = "Error loading pets: " + ex.toString();
                    url = "/customerManage.jsp";
                    }
                break;//end of case "doAllPets"
        }//end of switch

        
        session.setAttribute("customer", customer);
        session.setAttribute("message", message);
        session.setAttribute("sessionType", sessionType);
        
        return url;
    }
    
    
    private String doSearch(HttpServletRequest request, HttpServletResponse response)
    {
        String url = "";
        String message = "";
        String searchType = request.getParameter("searchType");
        String searchInput = request.getParameter("searchValue");
        Customer customer = new Customer();
        HttpSession session = request.getSession();
        String sessionType = "";
        

        switch(searchType)
        {
            case("phone"):
                if(ValidatorUtil.hasText(searchInput))
                {
                    if(ValidatorUtil.isAnyWholeNumber(ValidatorUtil.replaceNonNumerics(searchInput)))
                    {
                        if(searchInput.length() == 10)
                        {
                            if(CustomerDb.phoneExists(searchInput) == true)
                                try
                                {
                                customer = CustomerDb.getByPhone(searchInput);
                                String customerId = String.valueOf(customer.getCustomerId());
                                int stateId = customer.getStateId();
                                session.setAttribute("stateId", stateId);
                                session.setAttribute("customerId", customerId);
                                session.setAttribute("customer", customer);
                                message = "Is this still the correct information?";
                                url = "/customerAdd.jsp";
                                sessionType = "manage";
                                }
                                catch(SQLException ex)
                                {
                                message = ex.toString();
                                url = "/index.jsp";
                                }
                            else
                            {
                                if(ValidatorUtil.isValidPhone(searchInput) == true)
                                {
                                 customer.setPhone(searchInput);
                                 request.setAttribute("customer", customer);
                                 sessionType = "add";
                                 message = "Phone number not found. Please add a new customer";
                                 url = "/customerAdd.jsp";
                                }
                            }
                        }
                        else
                        {
                            url = "/index.jsp";
                            message = "Please enter a valid phone number";
                        }
                    }
                    else
                    {
                        url = "/index.jsp";
                        message = "Please enter a valid phone number";
                    }
                }
                else
                {
                    url = "/index.jsp";
                    message = "You must enter a phone number to search for";
                }
                break;
            case("lastName"):
                if(ValidatorUtil.hasText(searchInput))
                {
                    if(CustomerDb.nameExists(searchInput) == true)
                    {
                        try
                        {
                        List<Customer> customerList = CustomerDb.getByName(searchInput);
                        request.setAttribute("customerList", customerList);
                        sessionType = "manage";
                        url = "/customerManage.jsp";
                        }
                        catch(SQLException ex)
                        {
                        message = ex.toString();
                        url = "/index.jsp";
                        }
                    }
                    else
                    {
                        customer.setLastName(searchInput);
                        request.setAttribute("customer", customer);
                        sessionType = "add";
                        message = "Name not found. Please add new customer information";
                        url = "/customerAdd.jsp";
                    }
                }
                else
                {
                   url = "/index.jsp";
                   message = "Please enter a name to search";
                }
                break;
            case("allCustomers"):
                try
                {
                List<Customer> customerList = CustomerDb.getAll();
                request.setAttribute("customerList", customerList);
                sessionType = "manage";
                url = "/customerManage.jsp";
                }
                catch(SQLException ex)
                {
                message = ex.toString();
                url = "/index.jsp";
                }
                break;
        }//end of switch


        session.setAttribute("sessionType", sessionType);
        request.setAttribute("message", message);
        
        return url;
    }
    
    private String doCustomer(HttpServletRequest request,
            HttpServletResponse response)
    {
        //String customerNumber = getCustomerNumber();
        String message = "";
        String url;
        Customer customer = new Customer();
        boolean isValidAdd = false;
        int validCount = 0;
        int validTotal = 0;
        
        if(ValidatorUtil.isAlphabetic(request.getParameter("firstName")) == true)
        {
        String firstName = request.getParameter("firstName");
        customer.setFirstName(firstName);
        validCount++;    //validCount == 1
        }//end of if for firstName   
        validTotal++;
        
        if(ValidatorUtil.isAlphabetic(request.getParameter("lastName")) == true)
        {
        String lastName = request.getParameter("lastName");
        customer.setLastName(lastName);
        validCount++;//validCount == 2
        }//end of if for lastName
        validTotal++;
        
        
        if(ValidatorUtil.hasText(request.getParameter("address")))
        {
        String address = request.getParameter("address");
        customer.setAddress(address);
        validCount++;//validCount == 3
        }//end of if for address
        validTotal++;
        
        if(ValidatorUtil.isAlphabetic(request.getParameter("city")))
        {
            String city = request.getParameter("city");
            customer.setCity(city);
            validCount++;//validCount == 4
        }//end of if for city
        validTotal++;
        
        
        if(ValidatorUtil.hasText(request.getParameter("postalCode")))
        {
        String postalCode = request.getParameter("postalCode");
        customer.setPostalCode(postalCode);
        validCount++;//validCount == 5
        }//end of if for postalCode
        validTotal++;
        
        
        if(request.getParameter("select_state").toString().length() > 0)
        {
        int stateId = Integer.parseInt(request.getParameter("select_state"));
        customer.setState(stateId);
        validCount++;//validCount == 6
        }//end of if for select_state
        validTotal++;
        
        if(ValidatorUtil.isValidEmail(request.getParameter("email")) == true)
        {
        String email = request.getParameter("email");
        customer.setEmail(email);
        validCount++;//validCount == 7
        }//end of if for email
        validTotal++;
        
        if(ValidatorUtil.isValidPhone(request.getParameter("phone")) == true)
        {
        String phone = request.getParameter("phone");
        customer.setPhone(ValidatorUtil.replaceNonNumerics(phone));
        validCount++;//validCount == 8
        }//end of if for phone
        validTotal++;
        
        if(validCount == validTotal)
        {
        isValidAdd = true;
        url = "/petAdd.jsp";
        }
        else
        {
        url = "/customerAdd.jsp";
        message = "Please fill all fields correctly";
        }//end of else for phone
        
        if(ValidatorUtil.hasText(request.getParameter("comments")))
        {
            String comments = request.getParameter("comments");
            customer.setComments(comments);
        }
        
        HttpSession session = request.getSession();//move this into setPageData
        String sessionType = (String) session.getAttribute("sessionType");
        
        if(isValidAdd == true)
        {
        switch(sessionType)
                {
                    case("add"):
                        String phone = customer.getPhone();
                        if(CustomerDb.phoneExists(phone) == true)
                        {
                           url =  "/customerAdd.jsp";
                           message = "A customer with that phone number already exists";
                        }
                        else
                        {
                            try
                            {
                            //customer.setCustomerId(Integer.parseInt(customerNumber));
                            CustomerDb.insert(customer);
                            customer = CustomerDb.getByPhone(phone);
                            String customerId = String.valueOf(customer.getCustomerId());
                            message = "Customer was added successfully";
                            session.setAttribute("customerId", customerId);
                            }
                            catch(SQLException ex)
                            {
                            message = "Error while adding customer: " + ex.toString();
                            url = "/customerAdd.jsp";
                            }
                        }//end of else
                        break;
                    case("manage"):
                        try
                        {
                        String customerId = (String) session.getAttribute("customerId");
                        customer.setCustomerId(Integer.parseInt(customerId));
                        }
                        catch(NumberFormatException e)
                        {
                        //customer.setCustomerId(Integer.parseInt(customerNumber));
                        }
                        try
                        {
                        CustomerDb.update(customer);
                        String customerId = (String) session.getAttribute("customerId");
                        message = "Customer " + customerId + " was updated successfully";
                        }
                        catch(SQLException ex)
                        {
                        message = "Error while updating customer: " + ex.toString();
                        url = "/customerAdd.jsp";
                        }
                        break;
        }//end of switch
        }//end of inserting customer if statement
        //use an array list for this, they're more efficient
        //List<String> genderType = new ArrayList<>();
        //use an enhanced for loop
        
        //put all arrayList data in its own method, loadPageData()
        //call that method at the top of doPost, or the start of doGet
        
        
        
        session.setAttribute("customer", customer);
        request.setAttribute("message", message);
        
        
        
        return url;
    }//end of doCustomer
    
    private String doPet(HttpServletRequest request,                                  
            HttpServletResponse response)
    {
        boolean isValid = false;
        String message = "";
        String url;
        Pet pet = new Pet();
        int validCount = 0;
        int validTotal = 0;
        
        
        if(ValidatorUtil.isAlphabetic(request.getParameter("name")) == true)
        {
        String name = request.getParameter("name");
        pet.setName(name);
        validCount++;//validCount == 1
        }//end of if for name
        validTotal++;
        
        
        if(request.getParameter("select_gender").toString().length() > 0)
        {
        String gender = request.getParameter("select_gender");
        pet.setGender(gender);
        validCount++;//validCount == 2
        }  //end of if for gender 
        validTotal++;


        if(request.getParameter("select_type").toString().length() > 0)
        {
        int petTypeId = Integer.parseInt(request.getParameter("select_type"));
        pet.setPetTypeId(petTypeId);    
        validCount++;//validCount == 3
        }//end of if for petType
        validTotal++;


        if(DateUtil.isValidBirthDate(request.getParameter("birthDate")) == true)
        {
        String birthDate = request.getParameter("birthDate");
        pet.setBirthDate(birthDate);
        validCount++;//validCount == 4
        }//end of if for birthDate
        validTotal++;


        if(request.getParameter("select_disposition").toString().length() > 0)
        {
        int dispositionTypeId = Integer.parseInt(request.getParameter("select_disposition"));
        pet.setDispositionTypeId(dispositionTypeId);      
        validCount++;//validCount == 5
        }//end of if for disposiition
        validTotal++;

        
        if(DateUtil.isValidCoughDate(request.getParameter("coughDate")) == true)
        {
            String coughInput = request.getParameter("coughDate");
            boolean isValidCoughInput = false;
            
            try
            {
            LocalDate coughDate = DateUtil.getCoughDate(coughInput);
            pet.setCoughDate(DateUtil.getSqlDate(coughDate));
            isValidCoughInput = true;
            }
            catch(DateTimeParseException e)
            {
                LocalDate coughFromSQL = DateUtil.getCoughDateFromSQLDateInput(coughInput);
                pet.setCoughDate(DateUtil.getSqlDate(coughFromSQL));
                isValidCoughInput = true;
            }
        if(isValidCoughInput == true)
            {
                validCount++;//validCount == 6
            }
        }//end of if for coughDate
        validTotal++;
        
        
                
        if(ValidatorUtil.hasText(request.getParameter("comments")))
        {
            String comments = request.getParameter("comments");
            pet.setComments(comments);
            //not a required field, so no validCount and validTotal incrementing
        }
        
        
        if(validCount == validTotal)
        {
        isValid = true; 
        url = "/petAdd.jsp";
        }
        else
        {
        url = "/petAdd.jsp";
        message = "Please fill all fields correctly";
        }//end of else for coughDate

        
        HttpSession session = request.getSession();
        
        session.getAttribute("customer");
        
        //getting the customerId from the session to save it to the new pet
        String customerId = (String) session.getAttribute("customerId");
        pet.setCustomerId(Integer.parseInt(customerId));
        
        if(isValid == true)
        {
            try
            {
            PetDb.insert(pet);
            message = pet.getName() + " was added successfully for customer " + customerId;
            }
            catch(SQLException ex)
            {
            message = ex.toString();
            url = "/petAdd.jsp";
            }
        }//end of inserting pet if statement
        
        LocalDate localDate = DateUtil.getCurrentDate();
        
        session.setAttribute("pet", pet);
        request.setAttribute("message", message);
        request.setAttribute("localDate", localDate);
        
        //String petDispoLongDesc = getDispoLongDesc(pet);
        //request.setAttribute("petDispoLongDesc", petDispoLongDesc);
        
        return url;
        
    }//end of doPet, method to validate pet info and save pet to DB and session
    
    private void setPageData(HttpServletRequest request)
    {
        List<DispositionType> dispoType = DispositionTypeDb.getAllDispoTypes();
        List<StateList> stateList = StateListDb.getAllStates();
        List<PetType> petTypes = PetTypeDb.getAllPetTypes();
        List<PetType> petTypesActive = PetTypeDb.getAllActivePetTypes();
        
        HttpSession session = request.getSession();
        
        List<String> genderType = new ArrayList<>();
        for(GenderEnum gender : GenderEnum.values()){
            genderType.add(gender.toString());
        }

        session.setAttribute("petTypesActive", petTypesActive);
        session.setAttribute("stateList", stateList);
        session.setAttribute("dispoType", dispoType);
        session.setAttribute("petTypes", petTypes);
        session.setAttribute("genderType", genderType);
        //ServletContext application = this.getServletContext();//move this into setPageData
        //application.setAttribute("stateList", stateList);
        //application.setAttribute("petType", petType);
        //application.setAttribute("genderType", genderType);//move this into setPageData
        //application.setAttribute("dispoType", dispoType);//move this into setPageData
    }//this method saves drop-down info to the session

    
    private void resetMessage(HttpServletRequest request,
            HttpServletResponse response)
    {
        HttpSession session = request.getSession();
        session.removeAttribute("message");
        session.removeAttribute("pet");
    }//resets session information about the current pet and the current banner message
    
}
    
    