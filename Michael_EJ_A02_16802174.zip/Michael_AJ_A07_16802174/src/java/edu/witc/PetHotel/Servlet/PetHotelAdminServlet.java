/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.witc.PetHotel.Servlet;

import edu.witc.PetHotel.business.DispositionType;
import edu.witc.PetHotel.business.GenderEnum;
import edu.witc.PetHotel.business.PetType;
import edu.witc.PetHotel.business.StateList;
import edu.witc.PetHotel.data.DispositionTypeDb;
import edu.witc.PetHotel.data.PetTypeDb;
import edu.witc.PetHotel.data.StateListDb;
import edu.witc.PetHotel.util.ValidatorUtil;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author mlens_000
 */
public class PetHotelAdminServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response, String url)
            throws ServletException, IOException {
        
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            /*out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet PetHotelNewServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet PetHotelNewServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");*/
            getServletContext().getRequestDispatcher(url)
                .forward(request, response);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        
        String action = request.getParameter("action");
        String url = "";

        switch (action) 
            {
            case "customer":
                url = "/customerAdd.jsp";
                break;
            case "manage":
                url = "/customerManage.jsp";
                break;
            case "search":
                url = "/customerSearch.jsp";
                break;
            case "anotherOne":
                url = "/index.jsp";
                break;
            }
        processRequest(request, response, url);
        
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);
        
        String action = request.getParameter("action");
        String url = "";
        setPageData(request);
        
        
        
        switch(action)
        {
            case "doAdmin":
                url = doAdmin(request, response);
                break;
            case "doTypes":
                url = doTypes(request, response);
                break;
            case "doEmployees":
                url = "/error_404.jsp";
                break;
            case "error":
                url = "/error_404.jsp";
                break;
            case "doPetTypes":
                url = doPetTypes(request, response);
                break;
            case "doDispoTypes":
                url = doDispoTypes(request, response);
                break;
            case "doStates":
                url = doStates(request, response);
                break;
            case "doAddState":
                url = doAddState(request, response);
                break;
            case "doAddPetType":
                url = doAddPetType(request, response);
                break;
        }
        
        getServletContext().getRequestDispatcher(url)
            .forward(request, response);
    }//end of doPost
    
    private String doAdmin(HttpServletRequest request, HttpServletResponse response)
    {
        String url = "";
        
        
        url = "/adminLanding.jsp";
        
        return url;
    }
    
    private String doAddPetType(HttpServletRequest request, HttpServletResponse response)
    {
        String url = "/manageTypes.jsp";
        String message = "";
        PetType petType = new PetType();
        int validCount = 0;
        int validTotal = 0;
        
        
        //checking if new state name existsts already
        if (ValidatorUtil.isAlphabetic(request.getParameter("newPetType")) == true)
        {
            String newType = request.getParameter("newPetType");
            if (PetTypeDb.petTypeExists(newType) != true)
            {
                petType.setLongDesc(newType);
                petType.setShortDesc(newType);
                validCount++;
            }
            else
            {
                message = "That pet type already exists";
            }
        }
        else
        {
           message = "Please enter a valid name"; 
        }
        validTotal++;
        //done checking if new state name existsts already
        
        
        if (validCount == validTotal)
        {
            try
            {
                PetTypeDb.insert(petType);
                message = petType.getLongDesc() + " was added as a valid pet type";
                url = "/manageTypes.jsp";
                setPageData(request);
            }
            catch(SQLException ex)
            {
                message = "Error while adding pet type: " + ex.toString();
                url = "/manageTypes.jsp";
            }
            url = "/manageTypes.jsp";
            //message = "That state is new";
        }
        else
        {
            url = "/manageTypes.jsp";
        }
        
        request.setAttribute("message", message);
        return url;
    }
    
    
    private String doAddState(HttpServletRequest request, HttpServletResponse response)
    {
        String url = "/manageTypes.jsp";
        String message = "";
        StateList state = new StateList();
        int validCount = 0;
        int validTotal = 0;
        
        
        //checking if new state name existsts already
        if (ValidatorUtil.isAlphabetic(request.getParameter("newState")) == true)
        {
            String newState = request.getParameter("newState");
            if (StateListDb.stateExists(newState) != true)
            {
                state.setLongDesc(newState);
                validCount++;
            }
            else
            {
                message = "That state name already exists";
            }
        }
        else
        {
           message = "Please enter a valid name"; 
        }
        validTotal++;
        //done checking if new state name existsts already
        
        if (ValidatorUtil.isAlphabetic(request.getParameter("newState")) == true)//checking if the abbreviation exists already as short_desc
        {
            String newStateShort = request.getParameter("newStateCode");
            if (StateListDb.stateAbbrExists(newStateShort) != true)
            {
                state.setShortDesc(newStateShort);
                validCount++;
            }
            else
            {
                message = "That state code already exists";
            }
        }
        else
        {
           message = "Please enter a valid abbreviation"; 
        }//end checking if the abbreviation exists already as short_desc
        validTotal++;
        
        
        
        if (validCount == validTotal)//if statement to try inserting new state info into database
        {
            try
            {
                StateListDb.insert(state);
                message = "New state " + state.getLongDesc() + " was added";
                url = "/manageTypes.jsp";
                setPageData(request);
            }
            catch(SQLException ex)
            {
                message = "Error while adding state: " + ex.toString();
                url = "/manageTypes.jsp";
            }
            url = "/manageTypes.jsp";
        }
        else
        {
            url = "/manageTypes.jsp";
        }//end if statement to try inserting new state info into database
          
        
        request.setAttribute("message", message);
        return url;
    }
    
    private String doStates(HttpServletRequest request, HttpServletResponse response)
    {
        String url;
        String action = request.getParameter("action");
        String message = "";
        StateList state = new StateList();
        String stateId = request.getParameter("stateId");
        
        
        try
        {
            state = StateListDb.getById(stateId);
            state.setActive(!state.isActive());
            try 
            {
                StateListDb.updateValid(state);
                url = "/manageTypes.jsp";
                message = "state active status changed";
                setPageData(request);
            }
            catch(SQLException e)
            {
                message = "Error updating state:" + e;
                url = "/manageTypes.jsp";
            }
        }
        catch(SQLException ex)
        {
            message = "Error loading state value:" + ex;
            url = "/manageTypes.jsp";
        }
        
        request.setAttribute("message", message);
        return url;
    }
    
    private String doPetTypes(HttpServletRequest request, HttpServletResponse response)
    {
        String url;
        String action = request.getParameter("action");
        String message = "";
        PetType petType = new PetType();
        String petTypeId = request.getParameter("petTypeId");
        
        
        try
        {
            petType = PetTypeDb.getById(petTypeId);
            petType.setActive(!petType.isActive());
            try 
            {
                PetTypeDb.updateValid(petType);
                url = "/manageTypes.jsp";
                message = "pet type active status changed";
                setPageData(request);
            }
            catch(SQLException e)
            {
                message = "Error updating pet type:" + e;
                url = "/manageTypes.jsp";
            }
        }
        catch(SQLException ex)
        {
            message = "Error loading pet type value:" + ex;
            url = "/manageTypes.jsp";
        }
        
        request.setAttribute("message", message);
        return url;
    }
    
    private String doDispoTypes(HttpServletRequest request, HttpServletResponse response)
    {
        String url;
        String action = request.getParameter("action");
        String message = "";
        DispositionType dispoType = new DispositionType();
        String dispoId = request.getParameter("dispoId");
        
        
        try
        {
            dispoType = DispositionTypeDb.getById(dispoId);
            dispoType.setActive(!dispoType.isActive());
            try 
            {
                DispositionTypeDb.updateValid(dispoType);
                url = "/manageTypes.jsp";
                message = "disposition type active status changed";
                setPageData(request);
            }
            catch(SQLException e)
            {
                message = "Error updating disposition type:" + e;
                url = "/manageTypes.jsp";
            }
        }
        catch(SQLException ex)
        {
            message = "Error loading disposition type value:" + ex;
            url = "/manageTypes.jsp";
        }
        
        request.setAttribute("message", message);
        return url;
    }
    
    private String doTypes(HttpServletRequest request, HttpServletResponse response)
    {
        String url = "";
        
        url = "/manageTypes.jsp";
        
        return url;
    }  //not used

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    
    private void setPageData(HttpServletRequest request)
    {
        List<DispositionType> dispoType = DispositionTypeDb.getAllDispoTypes();
        List<StateList> stateList = StateListDb.getAllStates();
        List<PetType> petTypes = PetTypeDb.getAllPetTypes();
        
        
        HttpSession session = request.getSession();
        
        List<String> genderType = new ArrayList<>();
        for(GenderEnum gender : GenderEnum.values()){
            genderType.add(gender.toString());
        }

        session.setAttribute("stateList", stateList);
        session.setAttribute("dispoType", dispoType);
        session.setAttribute("petTypes", petTypes);
        session.setAttribute("genderType", genderType);
    }//this method saves drop-down info to the session
    
}
